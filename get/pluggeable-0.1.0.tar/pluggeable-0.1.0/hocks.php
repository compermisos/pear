<?php

function add_hock($function, $hock_name = "DEFAULT"){
	$_HOCKS[$hock_name][] = $function;
}

function remove_hock($function, $hock_name = "DEFAULT"){
	
}
function process_hock($hock_space = "DEFAULT"){
	return TRUE;
}
