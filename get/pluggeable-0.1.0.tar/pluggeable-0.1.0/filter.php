<?php
/**
 * Add Filters to the list
 * GLOBAL $filters
 * @todo validate duplicate filters
 *
 */
function add_filter($filter_name, $filter_space = "DEFAULT"){
	$_FILTERS[$filter_space][] = $filter_name;
}

function remove_filter($filter_name, $filter_space = "DEFAULT"){
	
}
function process_Filter($data, $filter_space = "DEFAULT"){
	return $return_data;
}
